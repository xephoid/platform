Game by Ionmark Games (http://ionmarkgames.com)

To Run:
Unzip the zip file.
Double click the PeopleDemo.jar inside the folder.

Instructions:
Arrow keys to move and jump
ESC quits
